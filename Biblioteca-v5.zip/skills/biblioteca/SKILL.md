---
name: "biblioteca"
description: "Busca a foto certa para cada manchete do VANTAGE TIMES (política, ações, empresas e os países cobertos) e entrega já tratada em degradê da paleta Vantage (1080x1350), com o carimbo VT na cor certa. Use com /biblioteca, ou logo depois do /pauta."
---

# /biblioteca — fotos em degradê Vantage

MANCHETE → tipo de assunto → fonte certa → foto + licença → degradê Vantage + carimbo VT → 1080×1350 → entrega com crédito.

Complementa `vantage-image-library` (seleção e licença) e `vantage-times-designer` (paleta e tipografia).

**Regra do Dericky:** capa e slides de manchete com foto real sempre que possível, degradê sobre a foto e VT no canto superior esquerdo.

**Modo liberal (pedido do Dericky, 10/10/2026):** não ser tão rigoroso nem ir atrás de foto em muitos lugares. Vale o que estiver na seção 0. Quando esta regra e outra parte da skill (ou a vantage-image-library) conflitarem na busca de foto, vale a seção 0.

## 0. Modo liberal — como buscar

1. **Foto boa o bastante serve.** Não precisa ser a foto do momento exato. Valem nesta ordem de preferência, e a primeira que aparecer já serve:
   - a pessoa ou empresa da notícia (foto de arquivo, retrato oficial, evento antigo);
   - o lugar (cidade, prédio do governo, sede, bolsa, porto, fronteira);
   - o tema (protesto genérico, petróleo, chips, dinheiro, bandeira do país).
2. **No máximo 2 tentativas por foto** (2 buscas ou 2 fontes). Não achou: usar foto do lugar ou do tema; não achou nem isso: fechar o slide com degradê chapado da editoria e seguir. Isso **não é erro** e não aciona o CEO Digital. Só registrar no log em uma linha ("slide X sem foto, melhoraria com <assunto>").
3. **Rede respondendo 429 (limite) ou 000 (bloqueio):** não esperar nem insistir; ir para a próxima fonte da lista uma vez e, falhando, seguir o item 2.
4. **Fontes liberadas** (todas, sem ordem obrigatória): Wikimedia Commons, Openverse, Flickr (CC BY, CC BY-SA, CC0 ou domínio público), Unsplash, Pexels, Pixabay, Agência Brasil, Agência Senado, Agência Câmara, Flickr e sites de governos, presidências, ministérios, bancos centrais, ONU, OTAN, UE, Kremlin, Kantei, Casa Branca, e salas de imprensa e banco de imagens oficiais das empresas.
5. **Foto oficial sem licença escrita** (governo, presidência, órgão público ou sala de imprensa de empresa): pode usar em post jornalístico com o crédito do órgão ou da empresa, com selo **USO EDITORIAL**. Não usar em post patrocinado.
6. **Conferência de rosto e assunto continua**: a pessoa da foto tem de ser a pessoa citada (nunca trocar por outra). Fora isso, aceitar sem caçar a foto perfeita.
7. **Continua proibido** (por direito autoral, não por rigor): Google Imagens, Pinterest, Instagram, fotos de outros jornais e de agências pagas (Reuters, AP, AFP, Getty, Folhapress, Estadão e afins). Foto de fonte pública com crédito dessas agências: descartar e pegar a próxima.

## 1. De onde vêm as manchetes

1. **Passadas junto com o comando** (`/biblioteca Petrobras anuncia...; Copom mantém Selic`).
2. **Um /pauta nesta conversa.** Se o /pauta já rodou (ou foi pedido na mesma mensagem: "/pauta e já passa no /biblioteca"), usar as **Top 5 pautas** dele sem pedir de novo. Prioridade: formato carrossel, depois urgência "hoje". Aproveitar a categoria e o país que o /pauta já indicou.
3. **Fotos anexadas** — pular a busca e ir ao passo 5.

Sem nada disso, perguntar quais manchetes ilustrar.

## 2. Categoria → tratamento

| Categoria | Preset | Fundo |
|---|---|---|
| mercados, ações, economia, análise, comércio exterior, negócios, institucional, breaking | petrol | Deep Petrol #092F35 |
| política, crise, investigação | ink | Ink Black #111111 (foto P&B) |
| geopolítica | lavender | Editorial Lavender #D8D2E8 |
| citação / personalidade em revista | paper | Paper #F2F0E9 |

Na dúvida → petrol.

## 3. Mapa de fontes por tipo de manchete (sugestão, não obrigação)

Extrair a entidade mais específica da manchete (pessoa, empresa, ticker, país, instituição) e começar pela fonte do tipo dela. Uma consulta já basta se trouxer foto usável; no máximo 2 (seção 0).

### 3.1 Política brasileira e autoridades
1. **Agência Senado e Agência Câmara (Flickr oficial)** — muitas fotos em CC BY 2.0. Crédito: `Fotógrafo/Agência Senado`.
2. **Agência Brasil (EBC)** — reprodução autorizada a veículos de comunicação com fins jornalísticos, citando a fonte. Crédito: `Fotógrafo/Agência Brasil`. Selo **SÓ JORNALÍSTICO** (não vale para publi).
3. **Flickr do Palácio do Planalto, ministérios, STF, TSE, Banco Central** — sem licença escrita → **USO EDITORIAL** com crédito do órgão (seção 0, item 5).
4. Wikimedia Commons para retratos oficiais.

### 3.2 Ações e mercado
- Capa de mercado com foto real (bolsa, prédio da empresa, sede do banco central, cidade financeira). O gráfico próprio do ativo, com os dados do dia, feito em Python nas cores Vantage, entra nos slides de número e gráfico.
- Bolsa como lugar: sala de imprensa da **B3**, Wikimedia Commons (NYSE, Nasdaq, bolsas europeias e asiáticas).
- Moedas, ouro, petróleo, soja, minério: Unsplash, Pexels, Pixabay, Openverse.

### 3.3 Empresas
1. **Sala de imprensa oficial da empresa** (newsroom, media center, banco de imagens). Selo **USO EDITORIAL** com o crédito pedido.
2. Wikimedia Commons: sede, fábricas, plataformas, lojas, executivos.
3. Unsplash, Pexels, Pixabay para contexto do setor.
Logo só quando a manchete for institucional; para fato real, foto de operação ou da sede.

### 3.4 Países cobertos pelo /pauta
Qualquer uma: acervo oficial do governo ou líder citado, Wikimedia Commons, ou Unsplash/Pexels/Pixabay para cidade e paisagem.

| País / bloco | Fonte oficial | Licença |
|---|---|---|
| 🇺🇸 EUA | Casa Branca, Departamento de Estado, Tesouro, Fed (Flickr) | obras do governo federal costumam ser domínio público; não usar sugerindo apoio |
| 🇪🇺 União Europeia | Serviço Audiovisual da Comissão Europeia; Flickr do Parlamento Europeu; BCE | crédito `© European Union` |
| 🇬🇧 Reino Unido | Flickr Number 10 e GOV.UK | em geral Open Government Licence |
| 🇯🇵 Japão | Kantei | crédito ao Kantei |
| 🇷🇺 Rússia | kremlin.ru | CC BY 4.0; crédito `www.kremlin.ru` |
| Demais países | site ou Flickr oficial do governo ou da presidência | sem licença escrita → **USO EDITORIAL** com crédito do governo |
| 🇨🇳 China | Wikimedia Commons (líderes em cúpulas, kremlin.ru, Kantei) | — |
| Encontros multilaterais | Flickr da ONU, da OTAN e da presidência anfitriã | crédito do órgão |

Geopolítica sem retrato bom: foto do lugar (capital, fronteira, porto, sede do governo) ou do tema; o mapa nas cores Vantage entra como slide de apoio.

### 3.5 Busca geral
- Openverse via WebFetch: `https://api.openverse.org/v1/images/?q=<termos em inglês>&license_type=commercial&aspect_ratio=tall`
- Wikimedia Commons via WebFetch: `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=<termos>&prop=imageinfo&iiprop=url|extmetadata&format=json`
- Unsplash, Pexels, Pixabay.
- VT Foto Inbox (pasta no Google Drive do usuário), para fotos que ele já separou.

### 3.6 O que registrar de cada foto
URL da página, autor ou órgão, licença (ou "oficial sem licença escrita") e crédito, num `creditos_fotos.md`, com um selo: **LIVRE COM CRÉDITO**, **USO EDITORIAL** ou **SÓ JORNALÍSTICO**. Preferir fotos com espaço negativo embaixo (o degradê cobre a metade inferior), mas sem gastar tentativa só por isso.

## 4. Baixar

Antes do primeiro download da sessão, testar a rede com `curl` em `upload.wikimedia.org` e `api.openverse.org` e registrar o resultado.

`curl -L -o fotos/<nome>.jpg <url>` numa pasta própria. Se o download for recusado pela rede (000, 403 de túnel ou 429), não tentar outro caminho para a mesma URL (nada de espelho ou cache): ir para outra fonte uma vez e, falhando, seguir a seção 0, item 2.

Nomear: `ENTIDADE_TEMA_TIPO_NN.jpg` (ex.: `petrobras_platform_context_01.jpg`).

## 5. Renderizar o degradê + carimbo VT

Os carimbos oficiais e o script ficam guardados no artifact **Carimbo VT** (https://claude.ai/artifact/HkmpXYenR7hxis5uLnbNYQ). No início de cada sessão, baixar os três arquivos para a pasta de trabalho com a ferramenta Artifact:

- `action: "read"`, `url: https://claude.ai/artifact/HkmpXYenR7hxis5uLnbNYQ`
- `paths: ["scripts/vt_gradient.py", "assets/VT_stamp_dark-background.png", "assets/VT_stamp_cream-background.png"]`
- `out_dir:` a pasta de trabalho

Arquivos:
- `scripts/vt_gradient.py` — degradê + carimbo VT automático (o carimbo também vem embutido no script)
- `assets/VT_stamp_dark-background.png` — V branco + T Signal Lime, fundo transparente
- `assets/VT_stamp_cream-background.png` — V escuro + T Signal Lime, fundo transparente

Se o artifact não abrir, avisar o usuário e pedir que anexe os dois carimbos; não desenhar o VT à mão.

Rodar por slide:

```
python3 scripts/vt_gradient.py fotos/<foto>.jpg saida/slide_01.jpg --categoria economia
python3 scripts/vt_gradient.py - saida/slide_05.jpg --categoria economia     # slide sem foto (número, gráfico, encerramento ou manchete sem foto achada)
```

O script imprime qual carimbo usou. Opções:
- `--direcao bottom|top|left|right` — de onde vem o fundo sólido (padrão bottom).
- `--inicio 0.35 --fim 0.82` — onde o degradê começa e vira cor sólida. Manchete longa → `--inicio 0.25`.
- `--foco 0.4` — recorte vertical (0 = topo, 1 = base). Rosto no alto → 0.2.
- `--preset` força um preset.
- `--carimbo auto|dark-background|cream-background|off` — padrão `auto` (segue a regra 5.1). `off` só quando o Designer for aplicar o VT depois.
- `--carimbo-largura 110` — largura do VT em px.
- `--carimbo-lado esquerda|direita` — padrão `esquerda`. **Regra da marca: carimbo VT no canto superior esquerdo, margem 64 px.** `direita` só com pedido explícito do usuário.

### 5.1 Regra da cor do símbolo VT (obrigatória)

O T é **sempre Signal Lime**. O que muda é a cor do V, conforme o fundo **onde o símbolo fica**:

| Fundo sob o símbolo | Carimbo | V |
|---|---|---|
| Deep Petrol, Ink Black, foto escura, degradê escuro | `VT_stamp_dark-background` | branco |
| Paper, Editorial Lavender, foto clara (céu, parede clara, neblina) | `VT_stamp_cream-background` | escuro |

- Decidir pelo **fundo real atrás do símbolo**, não pela categoria do slide. Em `auto` o script mede o brilho sob o símbolo e escolhe sozinho.
- Nunca V branco em fundo claro, nunca V escuro em fundo escuro.
- Nunca V em Lime, nunca T em outra cor, nunca o símbolo inteiro numa cor só.
- Não redesenhar, distorcer, girar, trocar proporções, nem aplicar sombra, contorno, brilho, 3D ou degradê no símbolo.
- Se o fundo sob o símbolo for muito misturado, ajustar `--foco` antes de aceitar.

## 6. Conferir antes de entregar

Abrir cada resultado com Read: degradê aplicado, carimbo VT no canto superior esquerdo e na versão certa (regra 5.1), pessoa certa quando houver rosto, metade de baixo limpa para a manchete em DM Serif Display, nada neon ou saturado. Se o assunto sumiu, ajustar `--foco` ou `--inicio` e renderizar de novo. Slide de manchete sem foto é aceito no modo liberal (seção 0, item 2), só com a linha no log.

## 7. Alternativa em HTML (só quando a entrega for HTML)

```css
.slide{width:1080px;height:1350px;background:
  linear-gradient(to bottom, rgba(9,47,53,.45) 0%, rgba(9,47,53,0) 20%, rgba(9,47,53,0) 35%, rgba(9,47,53,.97) 82%),
  url('<URL_DA_FOTO>') center 40%/cover}
```

Trocar 9,47,53 por 17,17,17 (política), 216,210,232 (geopolítica) ou 242,240,233 (paper).

## 8. Entrega

Para cada manchete, enviar o arquivo com SendUserFile e:

```
SLIDE 01 — <manchete>
Categoria: <categoria> → preset <preset> · Carimbo: <VT_stamp_dark-background ou VT_stamp_cream-background>
Foto: <descrição> — <fonte> — <selo de licença>
Crédito: <texto do crédito>
Página: <url>
```

No fim, a linha de créditos pronta para a legenda (ex.: `Fotos: Marcos Oliveira/Agência Senado; www.kremlin.ru`). Se algum slide ficou com **SÓ JORNALÍSTICO** ou **USO EDITORIAL**, lembrar que não vale para post patrocinado.

## Regras

- Rapidez antes de perfeição: a primeira foto usável e relacionada serve.
- Nunca trocar a pessoa da notícia por outra só porque a foto é melhor.
- Sempre dar crédito à fonte da foto.
- Nunca Google Imagens, Pinterest, Instagram, outros jornais ou agências pagas.
- Degradê sóbrio: sem neon, sem cores fora da paleta; Signal Lime nunca no degradê.
- Carimbo VT sempre na versão certa para o fundo atrás dele (regra 5.1) e sempre no canto superior esquerdo.
- Falta de foto não trava a peça: fecha com degradê chapado e registra no log.