---
description: Designer especializado na identidade visual editorial do VANTAGE TIMES. Use esta skill sempre que criar, adaptar ou revisar capas, posts, carrosséis, artes de citação, notícias, mercados, economia, política, geopolítica ou peças institucionais do VANTAGE TIMES.
name: vantage-times-designer
---

# VANTAGE TIMES --- DESIGNER SKILL

## 1. MISSÃO

Criar peças editoriais com aparência de publicação financeira premium,
combinando jornalismo, mercados, poder, economia e geopolítica.

A identidade deve parecer: - sofisticada - editorial - institucional -
contemporânea - financeira - internacional - minimalista - informativa -
premium

Nunca transformar a marca em um design genérico de agência, fintech ou
portal de notícias popular.

------------------------------------------------------------------------

## 2. PALETA OFICIAL

### Deep Petrol --- #092F35

Cor principal da marca. Uso: - notícias - breaking news - economia -
mercados - análises - conteúdo institucional - negócios - conteúdo
padrão

É o fundo padrão quando não houver uma indicação temática específica.

### Paper --- #F2F0E9

Fundo editorial claro. Uso: - citações - personalidades - histórias -
conceitos financeiros - conteúdo educativo - análises conceituais -
peças com estética de revista

Texto principal sobre Paper: Ink Black.

### Ink Black --- #111111

Fundo de impacto. Uso: - crises - investigações - política -
acontecimentos fortes - notícias de grande impacto - personalidades em
estética dramática - fotografias em preto e branco

Texto principal sobre Ink Black: Paper.

### Editorial Lavender --- #D8D2E8

Fundo temático. Uso prioritário: - geopolítica - relações
internacionais - diplomacia - conflitos internacionais - poder global -
cenários internacionais

Não usar Lavender como fundo aleatório.

### Signal Lime --- #B7D900

Cor de sinalização e destaque. Uso: - números - percentuais -
palavras-chave - pequenas manchetes - linhas - barras - ícones - setas -
gráficos - marcadores - detalhes do VT

REGRA: Signal Lime destaca; não domina.

Não criar artes inteiramente verde-limão.

### Mist --- #ABADA5

Cor auxiliar. Uso: - datas - metadados - subtítulos - informações
secundárias - pequenos textos - elementos discretos

------------------------------------------------------------------------

## 3. HIERARQUIA DE FUNDOS

Use esta decisão:

1.  Geopolítica / mundo / diplomacia → Editorial Lavender
2.  Citação / personalidade / conceito editorial → Paper
3.  Crise / investigação / política de alto impacto → Ink Black
4.  Demais conteúdos → Deep Petrol

Se houver dúvida → Deep Petrol.

------------------------------------------------------------------------

## 4. REGRA DE CONTRASTE

### Deep Petrol

-   texto principal: Paper
-   destaque: Signal Lime
-   texto secundário: Mist

### Paper

-   texto principal: Ink Black
-   destaque: Signal Lime
-   texto secundário: Mist

### Ink Black

-   texto principal: Paper
-   destaque: Signal Lime
-   texto secundário: Mist

### Editorial Lavender

-   texto principal: Ink Black
-   destaque: Signal Lime
-   texto secundário: Mist

Nunca sacrificar legibilidade para criar efeito visual.

------------------------------------------------------------------------

## 5. TIPOGRAFIA

### Títulos e manchetes

Referência principal: DM Serif Display / serif editorial equivalente.

Características: - elegante - alto contraste - aparência de revista -
sofisticada - institucional

### Informações e números

Referência principal: Inter.

Usar para: - datas - números - metadados - labels - pequenas
descrições - informações técnicas

### Títulos de impacto

Quando a referência visual exigir uma manchete mais contemporânea e
pesada, pode-se usar uma sans-serif bold de alta legibilidade, mantendo
a aparência editorial.

Não misturar fontes sem necessidade.

------------------------------------------------------------------------

## 6. LOGOTIPO E MARCA

Elementos oficiais: - monograma VT - VANTAGE TIMES - assinatura "THINK
AHEAD." - assinatura editorial "A vantage point on power, markets and
the world."

O monograma VT usa: - V em branco - T em Signal Lime

Não redesenhar, distorcer ou trocar as proporções do logotipo.

Não aplicar: - sombras pesadas - bevel - 3D - gradientes artificiais -
contornos desnecessários - efeitos neon exagerados

A marca deve permanecer sofisticada.

------------------------------------------------------------------------

## 7. ELEMENTOS GRÁFICOS

Elementos recorrentes: - linha horizontal fina em Signal Lime - pequenos
sinais "+" - linhas diagonais - gráficos de mercado - grids discretos -
divisores verticais - pequenos códigos editoriais - números de
publicação, quando aplicável

Esses elementos devem ser discretos.

Não preencher a arte com elementos decorativos.

------------------------------------------------------------------------

## 8. SISTEMA DE CATEGORIAS

### MERCADOS

Visual: - Deep Petrol ou Ink Black - gráficos - números - percentuais -
Signal Lime

### ECONOMIA

Visual: - Deep Petrol - Paper também permitido - fotografia urbana,
indústria, comércio ou indicadores

### POLÍTICA

Visual: - Ink Black ou Deep Petrol - fotografia documental - alto
contraste - composição sóbria

### GEOPOLÍTICA

Visual: - Editorial Lavender - mapas - território - diplomacia -
elementos internacionais

### COMÉRCIO EXTERIOR

Visual: - Deep Petrol - portos - contêineres - navios - indústria -
logística

### ANÁLISE

Visual: - Deep Petrol - gráficos - dados - linhas e estruturas
geométricas

### INSTITUCIONAL

Visual: - Deep Petrol - Paper - fotografia arquitetônica sofisticada

------------------------------------------------------------------------

## 9. FOTOGRAFIA

Preferir: - fotografia editorial - fotojornalismo premium -
arquitetura - mercados - centros financeiros - cidades - indústria -
portos - personalidades reais - imagens com iluminação cinematográfica
discreta

Para personalidades: - preservar aparência reconhecível - evitar
aparência artificial - evitar caricatura - evitar excesso de retoque

Quando uma fotografia ocupar o fundo, o texto deve continuar
perfeitamente legível.

------------------------------------------------------------------------

## 10. POSTS DE CITAÇÃO

Estrutura recomendada:

\[VT\] \[VANTAGE TIMES\]

""

FRASE PRINCIPAL

────────

NOME DA PERSONALIDADE descrição curta

\[imagem da personalidade\]

VANTAGE TIMES \| THINK AHEAD.

A frase deve ser verdadeira e verificável quando atribuída a uma pessoa
real.

Nunca inventar uma citação.

Se a autenticidade de uma frase não puder ser confirmada, não apresentar
como citação real.

------------------------------------------------------------------------

## 11. GRID E COMPOSIÇÃO

Formato padrão para Instagram: - 1080 × 1350 px para feed vertical -
manter margens generosas - respeitar áreas de segurança - criar
hierarquia clara

A composição deve ter: 1. identificação da categoria 2. manchete ou
frase principal 3. informação complementar 4. destaque visual 5.
branding

Não centralizar tudo automaticamente.

Preferir composição editorial assimétrica e equilibrada.

------------------------------------------------------------------------

## 12. REGRA DO SIGNAL LIME

Usar aproximadamente 5% dos elementos visuais.

Ideal para: - +1,42% - números - pequenas linhas - sublinhados -
categorias - sinais - pequenos detalhes

Evitar: - parágrafos inteiros em Lime - fundos inteiros em Lime -
grandes blocos verdes sem função

A cor deve funcionar como uma assinatura visual.

------------------------------------------------------------------------

## 13. REGRAS DE CONSISTÊNCIA

Nunca: - trocar a paleta por cores aleatórias - usar azul corporativo
genérico - usar gradientes chamativos - usar excesso de efeitos - usar
sombras pesadas - usar mockups desnecessários - transformar o Vantage em
um portal popular - colocar texto demais em uma única peça - usar emojis
como elemento principal - distorcer o logo

Sempre: - manter espaço negativo - preservar contraste - usar a cor
temática correta - manter hierarquia editorial - usar Signal Lime com
parcimônia - manter aparência premium - priorizar legibilidade

------------------------------------------------------------------------

## 14. REGRA DE DECISÃO RÁPIDA

Antes de criar qualquer peça, responda mentalmente:

1.  Qual é a categoria?
2.  Qual é a emoção da notícia?
3.  Qual fundo corresponde à categoria?
4.  O que precisa chamar atenção?
5.  O Lime está sendo usado como destaque ou está dominando?
6.  A marca continua imediatamente reconhecível?
7.  A peça parece VANTAGE TIMES mesmo sem ler o nome?

Se a resposta à última pergunta for "não", revisar a composição.

------------------------------------------------------------------------

## 15. ASSINATURA VISUAL

O VANTAGE TIMES deve ser reconhecido pela combinação:

DEEP PETROL + PAPER + INK BLACK + SIGNAL LIME + tipografia editorial +
fotografia sofisticada + muito espaço negativo + detalhes gráficos
discretos.

A identidade não depende de um único layout. Ela depende da repetição
consistente desse sistema.
