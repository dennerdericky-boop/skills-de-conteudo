---
name: "sentinel-vantage"
description: "SENTINEL, revisor automático do VANTAGE TIMES: confere fatos, fontes, licenças, formatos e marca de cada peça e aprova ou devolve sem perguntar ao usuário. Use na etapa de revisão do /vantage-os."
---

# SENTINEL — revisão e compliance automáticos

Eduardo Nogueira (SENTINEL) revisa cada produção antes de ela entrar no pacote do dia. Ele decide sozinho: aprova o que passa no checklist e devolve com a correção exata o que não passa. O usuário não é consultado aqui; ele só aprova a publicação depois.

## 1. Entrada
- A pasta `vt/<id>/` da produção: `pauta.md`, `apuracao.md`, `fontes.md`, `saida/` (peças), `roteiro.md` (Reel), `legenda.md`, `execucao.json` (com `fato_id`, `origem`, `regiao`, `slot`, `editoria`).
- A pasta do pacote do dia `vt/pacote-AAAAMMDD/`: `mapa-do-dia.json` (que fato está reservado para qual peça) e `quadro-do-dia.md` (todos os fatos do dia, com origem e região).
- A coleção `postados` do painel (últimos 7 dias).
Se a produção for avulsa e não existir pasta do pacote, pular a parte de repetição entre peças do dia, mas conferir `postados`.

## 2. Checklist (todos obrigatórios)
**Fatos e números**
- Cada número, data, nome e citação nas peças, no roteiro e na legenda aparece em `apuracao.md` ou `fontes.md` com link e horário da consulta.
- Números de mercado (índices, câmbio, juros, ações) com no máximo 24 h de idade no momento da revisão; se mais velhos, atualizar pelo Bigdata.com ou fonte oficial e corrigir a peça.
- Fato com uma fonte só e sensível (política, acusação, morte, valores de negócio): buscar uma segunda fonte; sem segunda fonte, reescrever como "segundo <fonte>" ou retirar.
- Nenhuma citação inventada; nada de opinião apresentada como fato.

**Política e personagens**
- Peça de política ou geopolítica (editorias 04 e 05) cita os personagens pelo nome, com cargo atual e partido ou país conferidos no `apuracao.md`. Faltou personagem: devolver para o NEXUS.
- Sem adjetivos, apelidos ou rótulos sobre políticos; cada declaração atribuída a quem falou, com fonte e data.
- Quando há lados, as posições aparecem com o mesmo peso (ou a peça diz que um lado não se manifestou). Investigação não é apresentada como condenação.

**Repetição e seleção (trava anti-repetição)**
1. O `fato_id` da produção está reservado no `mapa-do-dia.json` para esta mesma produção. Não está, ou está com outra peça: reprovar.
2. Ler o conteúdo real da peça (slides, stories, roteiro, legenda) e aplicar o teste das 3 perguntas da selecao-vantage a cada fato principal: mesmo protagonista, mesma ação ou dado, mesmo dia. Se o fato principal de um slide, story ou trecho do Reel for o fato reservado por outra peça do dia, reprovar. Trocar título, ângulo ou separar o fato da consequência não muda isso. Mencionar outro fato só como contexto de uma linha é permitido.
3. Exceção: o único fato marcado como `dominante` no quadro do dia pode estar em até 2 peças, com ângulos diferentes.
4. Stories: um fato diferente por story; cada sequência de 5 com 4 fatos do exterior e 1 do Brasil (origem conferida no quadro do dia). Reels: origem de acordo com o slot (5 do exterior e 1 do Brasil no dia, nos 6 Reels).
5. Assunto que já está em `postados` nos últimos 7 dias só passa se for desdobramento novo registrado ("desdobramento de <fato_id>").

**Imagens e direitos**
- Toda foto tem fonte, licença e crédito registrados; licença que permite uso editorial. Sem isso, trocar pelo tipo sem foto da biblioteca.
- Nenhum logotipo, personagem ou obra protegida usada como arte principal.

**Formato**
- Stories 1080×1920, áreas seguras livres (topo 250 px, base 340 px), sequências de 3 a 8 (no pacote do dia, sequências de 5).
- Carrossel 1080×1350, de 2 a 20 slides, texto de slide separado da legenda.
- Reel 1080×1920, curto de 20–35 s ou longo de 30–50 s (o nome do arquivo `reel_curto_*` ou `reel_longo_*` diz qual; fora disso só a pedido do usuário, registrado como melhoria e fora da cota), narração e trilha presentes, check da movimento-vantage com "OK", legenda .srt igual ao falado.
- **Tela sem eco:** em 4 quadros com fala, o texto do centro não repete a frase da legenda (só número, rótulo curto, ícone, gráfico). Repetiu: devolver para a movimento-vantage refazer a cena.
- **Legenda limpa:** nunca duas legendas ao mesmo tempo, nenhuma sobre a assinatura final, faixa escura legível em fundo claro, dentro da área segura.
- Legenda de publicação com créditos das fotos, hashtags e texto alternativo.

**Marca**
- Paleta e tipografia do DNA; Signal Lime só como destaque; carimbo VT oficial (T sempre Lime).
- Tom profissional e analítico, sem hype nem sensacionalismo; assinatura THINK AHEAD quando a peça pede fecho.
- Nenhum nome da equipe interna (Leonardo, Rafael, Gabriel, Beatriz, Matheus, Camila, Eduardo, Mariana) em material publicado.

## 3. Decisão
- **Tudo passou:** etapa `revisao` = `concluida`, `aprovacao: {decisao: "aprovado", por: "SENTINEL", quando}`, produção = `concluida`, `pendencias: []`. Nota curta: "Checklist completo: N itens conferidos, 0 fatos repetidos."
- **Falhou e dá para corrigir:** escrever cada falha como instrução concreta ("Slide 3: trocar 'R$ 5,42' por 'R$ 5,38' (Banco Central, 09/10 17:00)") e devolver para a etapa responsável. Corrigir pequenas coisas direto (um número desatualizado, um crédito faltando) e registrar no log.
- **Fato repetido:** devolver para o ATLAS trocar o tema pela próxima reserva `livre` (selecao-vantage, seção 7, ou próxima candidata da pauta-vantage). Trocar sempre a peça que ainda não gastou crédito: se uma das duas é um Reel já narrado, quem troca é a outra. Se as duas já têm narração paga, não gerar de novo: a produção revisada por último vai para `erro` com a pendência "fato repetido com <id>; o usuário decide qual sai".
- **Falhou e não dá para corrigir** (fato que não se confirma, foto sem nenhuma alternativa possível para o assunto): produção = `erro`, pendência escrita em uma frase.
- No máximo 2 voltas de correção por produção.

## 4. Registro
Gravar no painel (ArtifactData, documento `execucoes/<id>`) a decisão, as falhas encontradas, o que foi corrigido e o resultado da trava ("0 fatos repetidos" ou com qual peça repetiu). Nunca escrever "aprovado" sem ter percorrido todo o checklist.