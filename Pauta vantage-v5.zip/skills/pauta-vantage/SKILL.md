---
name: "pauta-vantage"
description: "Monta a pauta do dia do VANTAGE TIMES com notícias em tempo real, organizada pelas 10 editorias, tipo de conteúdo e público. Use com /pauta-vantage no lugar do /pauta."
---

# /pauta — O que postar hoje no VANTAGE TIMES

Objetivo: transformar as notícias e os dados de mercado **em tempo real** de Brasil e do mundo em ideias de posts, organizadas pelas editorias do VANTAGE TIMES, pensadas para o público certo e distribuídas pela regra de seleção diária (seção 8). Reels e Stories são escolhidos pela skill `selecao-vantage`, a partir desta pauta.

## 0. Regra principal: sempre em tempo real
- Toda execução busca dados novos. Nunca responda de memória nem reaproveite pauta antiga.
- Pegue a data e a hora atuais com a ferramenta de horário antes de buscar.
- Mostre o horário da coleta (Brasília) e indique se cada bolsa está **aberta, fechada ou em pré-mercado**.

## 1. Linha editorial do VANTAGE TIMES

### Posicionamento
O VANTAGE TIMES fica entre um portal de notícias financeiras e uma publicação de análise econômica e geopolítica. Toda pauta precisa responder a três perguntas:
1. **O que aconteceu?**
2. **Por que isso importa?**
3. **Quais podem ser as consequências** para mercados, empresas e economia?

A identidade visual sofisticada reforça a credibilidade, mas não substitui a apuração.

### Público
- **Prioritário:** 22 a 40 anos. **Secundário:** 18 a 50+. Brasil, em português, com interesse no que acontece no mundo.
- **Perfil:** investidores, empresários, executivos, profissionais e estudantes curiosos, ambiciosos e estratégicos, que querem entender os fatos para decidir melhor.
- Essas faixas são hipóteses estratégicas, não dados confirmados dos seguidores.

**Seis segmentos (marque em cada pauta qual ela atinge):**
| Segmento | Conteúdo que funciona |
|---|---|
| S1 Investidores | Maiores altas e quedas, indicadores, notícias que movem mercados |
| S2 Empresários e empreendedores | Balanços, fusões, aquisições, decisões corporativas, impostos |
| S3 Executivos e profissionais | Indicadores, estratégia empresarial, tendências globais |
| S4 Estudantes | Explicações de economia, conceitos financeiros, história econômica |
| S5 Política e geopolítica | EUA, China, governo, conflitos com efeito econômico |
| S6 Riqueza e influência | Bilionários, rankings, histórias empresariais, grandes grupos |

### Tipos de conteúdo
Toda pauta recebe um tipo:
- **Notícia urgente:** fato do dia, publicar já.
- **Análise:** o que o fato significa e o que pode vir depois.
- **Explicação:** conceito ou mecanismo em linguagem simples (ótimo para S4).
- **Ranking:** lista com critério, data e fonte (ótimo para carrossel).
- **Retrospectiva:** história econômica, linha do tempo e efemérides (perene).

## 2. As 10 editorias (categorias-mãe)
Cada pauta recebe **uma editoria principal** e pode receber **etiquetas** de outras, porque há sobreposição natural. Por exemplo, petróleo é commodity, energia e mercado de capitais ao mesmo tempo. Os subtemas abaixo servem de checklist de varredura.

**01 · Mercados e investimentos.** Bolsa, ações, fundos, renda fixa, câmbio, cripto e commodities.
- Renda variável: maiores altas e baixas (dia, semana, mês, ano), máximas e mínimas históricas, dividendos e JCP, recompras, desdobramentos, IPOs, follow-ons, fechamentos de capital e revisões de preço-alvo.
- Bolsa: Ibovespa, IDIV, small caps, índices setoriais, regras da B3, fluxo estrangeiro, volume, circuit breaker e leilões.
- Renda fixa: Tesouro Selic, IPCA+ e Prefixado; CDB, LCI, LCA; debêntures, CRI, CRA, marcação a mercado e leilões do Tesouro.
- Fundos: ações, multimercado, ETFs, FIIs, Fiagros, private equity e VC; captação, resgates e troca de gestores.
- Cripto: BTC, ETH, altcoins, stablecoins, tokenização, DeFi, ETFs, regulação, hacks e falências de exchanges.
- Derivativos: opções, futuros, DI futuro, dólar futuro, vencimentos, volatilidade implícita e liquidações.
- Internacional: NYSE, Nasdaq, Europa e Ásia; ADRs, BDRs, ETFs globais e risco-país.
- Alternativos: ouro, prata, imóveis, arte, private credit e hedge funds.

**02 · Economia.** Inflação, juros, PIB, emprego, crédito, contas públicas e indicadores.
- Brasil: IPCA, INPC, IGP-M, Selic e Copom, PIB e IBC-Br, Caged e PNAD, varejo, indústria, serviços, balança comercial, resultado primário, dívida bruta e líquida, Focus, confiança e dados regionais.
- Mundo: crescimento, inflação e emprego das grandes economias; recessão; dívida soberana; tarifas; cadeias globais; relatórios de FMI, Banco Mundial, OCDE e ONU.
- Bancos centrais: Copom, Fed, BCE, BoE, BoJ e outros; atas, falas, projeções, intervenções cambiais, reservas e efeito dos juros sobre bolsa, câmbio, crédito e imóveis. Cite quem decidiu ou falou (presidente e diretores do banco central).

**03 · Negócios e empresas.** Balanços, CEOs, fusões, aquisições, startups e grandes companhias.
- Resultados: receita, lucro, EBITDA, margens, dívida, guidance e o que veio acima ou abaixo do esperado.
- M&A e reestruturações: OPAs, joint ventures, recuperações judiciais, falências e venda de ativos.
- Grandes grupos: Petrobras, Vale, Itaú, Bradesco e BB; Apple, Microsoft, Nvidia, Amazon, Alphabet, Meta e Berkshire; trocas de CEO e sucessão.
- Startups: rodadas, unicórnios, VC e encerramentos.
- Governança: conselhos, compliance, remuneração de executivos e ESG.
- **Cobertura individual da B3:** bancos (Itaú, Bradesco, Santander, BB, BTG), petróleo e energia (Petrobras, Prio, Vibra, Raízen, elétricas), mineração e siderurgia (Vale, Gerdau, CSN, Usiminas), varejo (Magalu, Renner, Assaí, Carrefour, Mateus), tecnologia (Totvs), saúde (Rede D'Or, Hapvida, Fleury), educação (Cogna, Yduqs), alimentos (JBS, Marfrig, BRF, São Martinho), telecom (Vivo, TIM), construção (Cyrela, MRV, Direcional), logística (Localiza, Rumo, aéreas) e seguros (Porto, BB Seguridade). Para cada uma, acompanhe cotação, variação, resultados, dividendos, fatos relevantes, dívida, gestão e riscos.

**04 · Política e governo.** Executivo, Congresso, Judiciário, eleições, impostos e orçamento.
- Governo federal (MPs, decretos, ministérios), Câmara e Senado (votações, CPIs, emendas), arcabouço e metas fiscais, reforma tributária (IBS e CBS), STF, STJ e TSE com impacto econômico, Receita, Carf, CVM, Cade e agências reguladoras.
- Eleições: pesquisas, programas econômicos e efeito sobre juros, câmbio e bolsa.
- Estados e municípios: contas, dívidas, incentivos e concessões.
- **Personagens políticos (sempre):** toda pauta de política cita pelo nome os personagens envolvidos — presidente, ministros, governadores, prefeitos, presidentes da Câmara e do Senado, líderes de partido, relatores, parlamentares, ministros do STF, candidatos e dirigentes de órgãos. Para cada um: nome, cargo atual, partido (ou órgão) e o que fez ou disse, com fonte e data. Confirme o cargo na busca do dia, porque cargos mudam.

**05 · Mundo e geopolítica.** EUA, China, Europa, guerras, diplomacia e disputas globais.
- EUA (Casa Branca, Congresso, tarifas), China (indústria, Taiwan), UE, Rússia e Ucrânia, Oriente Médio e petróleo, América Latina, Ásia-Pacífico.
- G7, G20, BRICS, ONU, OMC, FMI; sanções, embargos, defesa, rotas comerciais e disputas por recursos.
- **Personagens (sempre):** cite pelo nome chefes de Estado e de governo, chanceleres, ministros, líderes de blocos e organismos e demais atores do fato, com cargo atual, país ou organismo, e o que fizeram ou disseram, com fonte e data.

**06 · Tecnologia e inovação.** IA, semicondutores, big techs, cibersegurança e startups.
- IA generativa e agentes, Nvidia e chips, OpenAI e big techs, data centers e nuvem, robótica, ciberataques, regulação de IA, carros elétricos e baterias, fintechs e pagamentos, e o impacto da tecnologia no emprego.

**07 · Setores estratégicos.** Agro, energia, petróleo, mineração, indústria e infraestrutura.
- Agro: soja, milho, café, açúcar, algodão, boi gordo, frango, safras, clima, fertilizantes, crédito rural, barreiras sanitárias e preço dos alimentos.
- Energia: Brent e WTI, OPEP+, gás, refino, tarifas elétricas, renováveis, nuclear, etanol, minerais críticos e transição energética.
- Mineração e indústria: minério, cobre, produção industrial, política industrial, nearshoring e comércio exterior.
- Infraestrutura e logística: concessões, leilões, portos, ferrovias, fretes, aéreas e grandes obras.
- Imobiliário: preços, aluguéis, vacância, MCMV, crédito imobiliário e incorporadoras.
- Clima e riscos: eventos extremos, mercado de carbono e seguros contra desastres.

**08 · Finanças e patrimônio.** Finanças pessoais, bancos, crédito, fortunas e planejamento patrimonial.
- Bancos: resultados, inadimplência, provisões, fintechs, Pix, Open Finance, fraudes bancárias e intervenções.
- Bolso do leitor: juros e inflação no orçamento, reserva de emergência, comparação de investimentos, IR, aposentadoria, previdência, endividamento e sucessão patrimonial.
- Carreira e trabalho: demissões em massa, salários, profissões em alta e IA no emprego.
- Consumo: varejo, datas comerciais, e-commerce, turismo e automóveis.

**09 · Poder e personalidades.** Bilionários, líderes, rankings, histórias empresariais e influência.
- Rankings de fortunas, quem ganhou ou perdeu bilhões, sucessões, filantropia, Buffett, Musk e outros, mulheres nos negócios e novas gerações.
- Rankings e comparações: maiores empresas, maiores pagadoras de dividendos, bancos mais rentáveis, PIB por país, moedas, marcas, CEOs mais bem pagos e startups mais valiosas.
- Influência: CEOs e fundadores que mudaram setores, gestores de destaque e famílias empresariais.
- Secundário: esportes como negócio (clubes, direitos de TV, SAFs) e luxo pelo ângulo econômico (marcas, relógios, arte, aviação executiva).

**10 · Investigações e grandes histórias.** Fraudes, crises corporativas, pesquisas, história econômica e análises especiais.
- Fraudes contábeis, pirâmides, corrupção empresarial, recuperações judiciais, crises de reputação e sanções regulatórias.
- Pesquisas e estudos de consultorias, universidades e organismos.
- História econômica: 1929, o fim do padrão-ouro, 1973, a hiperinflação e o Plano Real, 1997, a bolha pontocom, 2008, a crise do euro, a pandemia e a ascensão da China. Procure **efemérides do dia** para retrospectivas.
- Saúde e farma pelo ângulo econômico: aprovações, patentes e planos de saúde.

## 3. Mapa de mercados (para a varredura)
**Prioridade diária (monitore primeiro):** financeiro e capitais, câmbio, juros, commodities, corporativo e internacional.

**Demais grupos (destaque quando houver fato):** imobiliário e ativos reais; consumo e trabalho; tecnologia; sustentabilidade e transição verde (renováveis, carbono, hidrogênio, baterias); seguros e risco (resseguro, previdência, catástrofes climáticas); alternativos (arte, luxo, colecionáveis, direitos musicais, esportes, mídia, recebíveis).

## 4. Fontes (sempre consultar)

### Conectores
Bigdata.com (`bigdata_market_tearsheet`, `bigdata_country_tearsheet`, `bigdata_events_calendar`, `bigdata_search`, `bigdata_company_tearsheet`) e outros conectores financeiros, se houver. Se o Bigdata.com não estiver conectado, avise e siga com as demais fontes.

### Sites de mercado fixos
Consulte com WebFetch (e WebSearch restrito ao domínio, via `allowed_domains`, quando a página não carregar):
- **TradingView** (br.tradingview.com): cotações, maiores altas e baixas, análise técnica.
- **Investing.com** (br.investing.com): cotações globais e calendário econômico.
- **Status Invest** (statusinvest.com.br) e **Investidor10** (investidor10.com.br): fundamentos, dividendos e P/L de ações e FIIs.
- **B3** (b3.com.br): dados oficiais. As cotações públicas podem ter **cerca de 15 minutos de atraso**; sinalize quando usar.

Se duas fontes divergirem, mostre a fonte e o horário de cada número.

### Veículos de notícias fixos
- **Valor Econômico**, **InfoMoney**, **Forbes Brasil**, **InvestNews**, **Bloomberg / Bloomberg Línea**, **Wall Street Journal**.
- Também Reuters, Estadão, Folha e veículos locais dos países cobertos.
- Valor, Bloomberg e WSJ têm paywall: use títulos e trechos abertos, confirme em fonte aberta e nunca contorne o paywall.

### Fontes oficiais e de dados
- **Brasil:** Banco Central (Selic, Copom, Focus, crédito), IBGE (IPCA, PIB, PNAD), IPEA/Ipeadata, Tesouro Nacional, Receita Federal, CVM, Anbima e B3.
- **Política (Brasil):** sites e agências da Câmara, do Senado, do Planalto e dos ministérios, do STF e do TSE (votações, tramitação, decisões, agendas oficiais e declarações), além dos veículos fixos para repercussão.
- **Exterior:** Fed, BCE, Eurostat, BLS e institutos nacionais; FMI, Banco Mundial, OCDE e OMC; sites oficiais dos governos para declarações de líderes.
- **Fortunas:** Forbes Real-Time Billionaires e Bloomberg Billionaires Index, sempre atribuindo o ranking à fonte.

Números oficiais vêm das fontes oficiais; os veículos servem para contexto e repercussão.

### Quando uma fonte falhar
Diga qual falhou e use as outras; nunca contorne bloqueios. Se o navegador do app estiver disponível e o usuário quiser, ele pode ser usado para ler essas páginas.

## 5. Países cobertos
Se o usuário indicar outra lista ou um foco, siga o pedido.
- **Prioridade máxima:** 🇧🇷 Brasil
- **Principais:** 🇺🇸 EUA · 🇨🇦 Canadá · 🇦🇺 Austrália · 🇪🇺 União Europeia
- **UE, nível do bloco (sempre):** BCE, euro, Euro Stoxx 50, Comissão e Parlamento Europeu, tarifas da UE.
- **UE, destaque sempre:** 🇩🇪 Alemanha (DAX) · 🇫🇷 França (CAC 40) · 🇮🇹 Itália (FTSE MIB) · 🇪🇸 Espanha (IBEX 35) · 🇳🇱 Países Baixos (AEX)
- **UE, monitorar:** 🇦🇹 Áustria · 🇧🇪 Bélgica · 🇧🇬 Bulgária · 🇨🇿 Chéquia · 🇨🇾 Chipre · 🇭🇷 Croácia · 🇩🇰 Dinamarca · 🇸🇰 Eslováquia · 🇸🇮 Eslovénia · 🇪🇪 Estónia · 🇫🇮 Finlândia · 🇬🇷 Grécia · 🇭🇺 Hungria · 🇮🇪 Irlanda · 🇱🇻 Letónia · 🇱🇹 Lituânia · 🇱🇺 Luxemburgo · 🇲🇹 Malta · 🇵🇱 Polónia · 🇵🇹 Portugal · 🇷🇴 Roménia · 🇸🇪 Suécia
- **UE fora do euro (moeda e banco central próprios):** Chéquia, Dinamarca, Hungria, Polónia, Roménia e Suécia. Confirme na busca se houve mudança recente na adesão ao euro.
- **Demais países:** 🇬🇧 Reino Unido · 🇨🇭 Suíça · 🇨🇳 China · 🇯🇵 Japão · 🇮🇳 Índia · 🇰🇷 Coreia do Sul · 🇲🇽 México · 🇦🇷 Argentina · 🇨🇱 Chile · 🇨🇴 Colômbia · 🇿🇦 África do Sul · 🇸🇦 Arábia Saudita · 🇹🇷 Turquia · 🇷🇺 Rússia · 🇮🇩 Indonésia

## 6. Coleta (buscas separadas)
1. **Mercados por país (últimas 24 h):** principal índice, moeda contra o dólar e o real, juros de 10 anos, banco central, economia, política e negócios.
2. **Brasil em detalhe:** Ibovespa, dólar, DI futuro, maiores altas e baixas da B3, dados oficiais divulgados no dia, manchetes de Valor, InfoMoney, InvestNews e Forbes Brasil, e fundamentos das empresas em destaque.
3. **Varredura por editoria:** faça ao menos uma busca dedicada a cada uma das 10 editorias, para que nenhuma fique sem olhar. Nas editorias 09 e 10, procure também rankings recém-publicados, movimentos de fortunas, investigações em andamento e efemérides econômicas do dia. Para encher as cotas da seção 8, levante pelo menos 3 candidatas por editoria fixa (01 a 05) e 2 por editoria do rodízio do dia.
4. **Personagens políticos:** nas editorias 04 e 05, identifique quem são os protagonistas de cada fato (quem propôs, votou, decidiu, discursou, criticou ou defendeu) e confirme nome, cargo atual e partido ou país em fonte oficial ou em dois veículos.
5. **Países menores da UE:** buscas agrupadas (Europa Central e Leste, Nórdicos e Bálticos, Benelux, Sul da Europa), aprofundando só onde houver fato.
6. **Ativos globais:** Brent e WTI, gás TTF, ouro, prata, cobre, minério de ferro, soja, milho, café, boi gordo, bitcoin e ethereum.

Confirme os números em pelo menos uma fonte e registre o horário de cada cotação. Guarde todos os fatos encontrados (não só os escolhidos): eles formam o quadro do dia que a `selecao-vantage` usa para Reels e Stories.

## 7. Pontuação
Pontue cada notícia de 1 a 5 em: relevância para o público brasileiro, impacto no bolso e nos investimentos, potencial de engajamento, urgência e facilidade de explicar.
- Notícias internacionais ganham pontos quando afetam o Brasil (dólar, juros, commodities, exportações, Mercosul–UE).
- Notícias repercutidas por vários veículos ganham pontos de engajamento.
- Rankings, bilionários e "maiores altas e quedas" tendem a engajar em carrossel; considere isso no engajamento.
- **Desempate:** vence a que mexe mais no bolso do brasileiro; persistindo o empate, a mais urgente.

## 8. Regra de seleção diária (pacote do dia)
A pontuação da seção 7 ordena as candidatas; esta regra decide **quantas peças de cada tipo** entram e **de quais editorias**. Sempre que a pauta for usada para montar o pacote do dia (inclusive pelo `/vantage-os pacote`), siga esta regra.

### 8.1 Tamanho do pacote
| Formato | Quantidade | Quem escolhe os temas |
|---|---|---|
| Carrossel | 15 | Esta skill (seções 8.2 a 8.4) — rankings, explicações, balanços, política e temas que pedem contexto |
| Reel longo (30–50 s) | 3 | `selecao-vantage` (80% exterior, 20% Brasil) |
| Reel curto (20–35 s) | 3 | `selecao-vantage` (80% exterior, 20% Brasil) |
| Stories | 15 (três sequências de 5: manhã, tarde e noite) | `selecao-vantage` (80% exterior, 20% Brasil) |

Os carrosséis são escolhidos primeiro e reservam seus fatos no mapa do dia; Reels e Stories escolhem depois, só entre os fatos que sobraram.

### 8.2 Divisão dos 15 carrosséis (dias úteis)
- **Cotas fixas (10):** 2 de Mercados (01), 2 de Economia (02), 2 de Negócios e empresas (03), 2 de Política (04) e 2 de Mundo e geopolítica (05). Política e geopolítica sempre com personagens citados.
- **Rodízio (3):** 3 editorias diferentes entre 06, 07, 08, 09 e 10, alternando a cada dia para que as cinco apareçam na semana. Ordem de partida: dia 1 → 06, 07, 08; dia 2 → 09, 10, 06; dia 3 → 07, 08, 09; e assim por diante. Use o histórico de `postados` para saber de onde continuar; sem histórico, comece do dia 1.
- **Perene (1):** uma explicação ou retrospectiva que não depende do noticiário (conceito, efeméride do dia ou ranking histórico).
- **Livre (1):** a candidata de maior pontuação que ainda não entrou, de qualquer editoria.

### 8.3 Fim de semana (bolsa fechada)
Mesmo tamanho de pacote, com estes ajustes nos carrosséis:
- Os 2 de Mercados viram **balanço da semana** (Ibovespa, dólar, maiores altas e baixas da semana) e **o que esperar da próxima semana**.
- Os 2 de Economia incluem a **agenda da semana** (IPCA, Copom, Fed, payroll e outros dados previstos).
- **Perenes sobem para 3:** o slot livre e 1 do rodízio viram perenes (explicação, retrospectiva ou ranking).
- Reels e Stories de fim de semana seguem a seção própria da `selecao-vantage`.

### 8.4 Limites
- No máximo **3 carrosséis da mesma editoria** no dia (somando cotas, rodízio e livre), salvo se um fato dominar o noticiário; nesse caso, registre o motivo.
- **Nenhum fato repetido no dia, em nenhum formato:** cada fato vai para uma única peça (trava anti-repetição da `selecao-vantage`, seção 3). Mudar título ou ângulo não torna o fato diferente. Exceção: 1 fato dominante por dia pode aparecer em até 2 formatos.
- **Pelo menos 3 rankings** entre os 15 carrosséis.
- **Pelo menos 3 tipos de conteúdo** no pacote (notícia urgente, análise, explicação, ranking, retrospectiva).
- **Assunto dos últimos 7 dias** só volta com fato novo; diga qual é o fato novo.
- **Segmentos:** os 6 segmentos (S1 a S6) atendidos pelo menos uma vez por dia no pacote.
- **Falta de pauta:** se uma editoria fixa não tiver fato relevante no dia, o slot vira explicação ou ranking da mesma editoria (não empurre notícia fraca só para cumprir cota).

## 9. Entrega
1. **Horário da coleta** e status das bolsas.
2. **Painel por região** (Américas, UE, Resto da Europa, Ásia-Pacífico, Oriente Médio e África): uma linha por país com bandeira, índice, moeda e fato do dia. Na UE, os 5 destaques sempre aparecem; os demais vão numa tabela compacta.
3. **Destaques da B3:** maiores altas e baixas e empresas em evidência, com P/L e dividend yield quando forem pauta.
4. **Top 5 pautas**, cada uma com:
   - **Editoria** (01–10) e etiquetas
   - **Tipo de conteúdo** (notícia urgente, análise, explicação, ranking ou retrospectiva)
   - **Segmento de público** (S1–S6)
   - **Gancho** (título forte para a capa)
   - **O que aconteceu** (2–3 frases, com fonte)
   - **Personagens** (obrigatório em política e geopolítica; nas demais, quando houver político envolvido): nome, cargo, partido ou país e o que fez ou disse, com fonte e data
   - **Por que importa** para o seguidor brasileiro
   - **Consequências possíveis** para mercados, empresas e economia
   - **Formato sugerido** (reel, carrossel ou stories) e **urgência** (hoje, esta semana ou perene)
5. **Carrosséis do dia (seção 8):** tabela com os 15 — slot (cota, rodízio, perene ou livre), editoria, tipo, segmento, `fato_id` e gancho de uma linha. Indique se é dia útil ou fim de semana e quais editorias estão no rodízio. Quando rodar com a `selecao-vantage`, juntar a tabela de Reels e Stories dela (pacote de 36 peças).
6. **Radar das 10 editorias:** uma linha por editoria com o melhor fato do dia, ou "sem novidade relevante". Nas linhas de 04 e 05, cite os personagens principais.
7. **Pauta perene da semana:** uma explicação ou retrospectiva que não depende do noticiário (efeméride, conceito ou ranking).
8. **Agenda dos próximos 7 dias:** IPCA, PIB, emprego, Copom, Fed e outros bancos centrais, payroll e CPI dos EUA, balanços, vencimentos de opções e futuros, leilões do Tesouro e concessões, datas com dividendos e assembleias, G7, G20, BRICS e cúpulas da UE, eleições, votações previstas no Congresso e discursos importantes, com quem vai falar ou votar.
9. **Fontes** com links de todas as páginas usadas.

Como o painel cobre mais de 45 países e o pacote tem 36 peças, entregue na conversa o Top 5, a B3, o radar e a agenda, e ofereça em uma linha o painel completo e a tabela do pacote como documento ou dashboard.

## 10. Cuidados editoriais
- Não faça recomendação de compra ou venda; sugira o aviso "não é recomendação de investimento" nos posts.
- **Política equilibrada, com personagens:**
  - Cite os políticos envolvidos pelo nome, cargo e partido, sem adjetivos, apelidos ou rótulos.
  - Atribua cada declaração a quem a fez, com fonte e data; citação direta só se estiver confirmada no veículo ou no registro oficial, e curta.
  - Quando houver lados (governo e oposição, autor e críticos, países em disputa), mostre a posição de cada um com o mesmo peso. Se um lado não se manifestou, diga isso.
  - Fato e opinião separados: o que foi aprovado, decidido ou dito é fato; avaliação sobre o político não entra.
  - Não tome partido nem sugira voto. Nos 4 carrosséis de política e geopolítica do dia, evite que todos tenham o mesmo lado como protagonista.
- Não invente números nem citações; diga quando algo não foi confirmado ou o dado está atrasado.
- Parafraseie as notícias com suas próprias palavras e cite sempre o veículo.
- **Rankings:** informe sempre o critério, a data de referência e a fonte. "Maior empresa" pode ser por receita, lucro, funcionários ou valor de mercado.
- **Fortunas:** diferencie patrimônio estimado de dinheiro disponível e atribua o ranking à fonte (Forbes, Bloomberg).
- **Fraudes e investigações:** separe suspeita, acusação, investigação e fato comprovado. Investigação aberta não é condenação; isso vale também para políticos investigados.
- **Influência:** diferencie listas editoriais de influência de rankings quantitativos; influência não é medida objetiva.
- **Sobreposição:** uma notícia pode ter mais de uma etiqueta; escolha a editoria principal pelo ângulo do post.

## 11. Rotina (opcional)
Se o usuário quiser receber a pauta automaticamente, ofereça tarefas agendadas, por exemplo: 7h45 (antes da abertura), 12h45 (meio do pregão) e 18h15 (fechamento), horário de Brasília, dias úteis.