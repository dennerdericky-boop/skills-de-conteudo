---
name: "selecao-vantage"
description: "Escolhe os temas dos 15 Stories e dos 6 Reels do dia do VANTAGE TIMES a partir de tudo o que está acontecendo, com 80% exterior e 20% Brasil e sem repetir fato já usado em outro formato. Use com /selecao-vantage ou no /vantage-os pacote."
---

# /selecao-vantage — Seleção dos temas de Stories e Reels

Objetivo: colocar na mesa **tudo o que está acontecendo no dia** (o quadro do dia), e escolher dele os temas dos **15 Stories** e dos **6 Reels** (3 longos de 30–50 s e 3 curtos de 20–35 s), com foco no exterior (80%) e no Brasil (20%), sem repetir nenhum fato que já foi para os carrosséis ou para outro formato.

Os carrosséis continuam sendo escolhidos pela /pauta-vantage (seção 8). Esta skill escolhe só Stories e Reels e cuida da trava anti-repetição entre os três formatos.

## 0. Comandos
| Comando | O que faz |
|---|---|
| `/selecao-vantage quadro` | Monta e mostra o quadro do dia (todos os fatos, com status) |
| `/selecao-vantage quadro atualizar` | Acrescenta ao quadro os fatos novos desde a última atualização, sem mudar números nem status dos que já estão lá |
| `/selecao-vantage stories` | Escolhe os 15 Stories |
| `/selecao-vantage stories manha\|tarde\|noite` | Escolhe só uma sequência de 5 (usado nas rodadas do /vantage-os) |
| `/selecao-vantage reels` | Escolhe os 6 Reels |
| `/selecao-vantage pacote` | Quadro + Reels + Stories, nessa ordem, respeitando os carrosséis já escolhidos |
| `/selecao-vantage trocar <peça> <nº do fato>` | Troca o tema de uma peça (ex.: `trocar story-07 23`) |

## 1. Regra de ouro: tudo na mesa antes de escolher
- Toda seleção começa pelo **quadro do dia** completo, e o quadro inteiro é sempre entregue ao usuário (uma linha por fato), para ele ver tudo o que está acontecendo e poder trocar qualquer escolha.
- Dentro do `/vantage-os` não há parada: a seleção é feita, o quadro fica no painel e no chat, e o usuário troca com `/selecao-vantage trocar` se quiser. Fora do `/vantage-os`, entregar o quadro e a seleção juntos, também sem esperar resposta.
- Sempre em tempo real: pegar data e hora atuais antes de buscar e nunca reaproveitar quadro de outro dia.

## 2. Quadro do dia
1. **Base:** a /pauta-vantage completa do dia. Se ela rodou há menos de 1 h (`vt/pacote-AAAAMMDD/pauta-completa.md`), reaproveitar; senão, carregar a skill `pauta-vantage` e rodar a coleta (seções 0, 4, 5 e 6).
2. **Reforço no exterior:** como 80% dos Stories e Reels são de fora, buscar a mais, por região: EUA; UE e países europeus (incluindo os 22 menores, em buscas agrupadas); Reino Unido e Suíça; Ásia-Pacífico (China, Japão, Índia, Coreia do Sul, Indonésia, Austrália); América Latina (México, Argentina, Chile, Colômbia); Canadá; Oriente Médio e África (Arábia Saudita, Turquia, África do Sul); Rússia; e globais (petróleo, ouro, cripto, FMI, OMC, G7, G20, BRICS). Usar agências (Reuters, Bloomberg) e veículos locais.
3. **Mínimo:** 40 fatos no quadro, sendo pelo menos 28 do exterior e pelo menos 1 de cada região acima. Região sem fato relevante: escrever "sem novidade relevante" na região.
4. **Cada fato no quadro tem:**
   - `nº` (1, 2, 3...) e `fato_id` (protagonista + ação + data, ex.: `fed-corta-juros-2026-10-10`)
   - Região e país (com bandeira), origem (`exterior` ou `brasil`), editoria (01–10)
   - Resumo em uma linha, personagens (nome, cargo, partido ou país), fonte e horário
   - Nota (pontuação da seção 7 da pauta-vantage)
   - Status: `livre`, `carrossel`, `reel`, `story`, `bloqueado-7-dias` ou `descartado` (com motivo)
5. Salvar em `vt/pacote-AAAAMMDD/quadro-do-dia.md` e no painel (`pacotes/<data>.quadro`).
6. **Atualizar (`quadro atualizar`):** buscar o que aconteceu desde o horário da última atualização (gravado no topo do quadro), acrescentar os fatos novos com os próximos números e marcar como desdobramento os que continuam um fato já listado. Nunca renumerar nem mudar o status de um fato já reservado. Gravar o novo horário de atualização.

**Origem Brasil ou exterior:** conta como `brasil` o fato que acontece no Brasil ou tem protagonista brasileiro (governo, Congresso, STF, BC, empresa brasileira, B3). Fato de fora com efeito no Brasil (ex.: Fed, China, petróleo) conta como `exterior`, e a peça pode citar o efeito no Brasil em uma linha.

## 3. Trava anti-repetição (vale para os três formatos)
**Mapa do dia:** `vt/pacote-AAAAMMDD/mapa-do-dia.json` = `{fato_id: {formato, peca_id, quando}}`. Todo fato escolhido para qualquer peça entra no mapa na hora em que é escolhido. O mapa vale para o dia inteiro, em todas as rodadas.

**Ordem de reserva:** 1) carrosséis (pauta-vantage seção 8); 2) Reels; 3) Stories. Cada formato só escolhe fato com status `livre`.

**Teste do mesmo fato (3 perguntas):**
1. É o mesmo protagonista (pessoa, país, empresa, órgão)?
2. É a mesma ação, decisão, fala ou dado?
3. É do mesmo dia ou do mesmo acontecimento?

Três "sim" = **mesmo fato**, e ele fica bloqueado para os outros formatos.
- **Não vale para fugir da trava:** trocar só o título, mudar o ângulo, separar o fato da consequência ("Fed corta juros" e "o que o corte do Fed muda no dólar" são o mesmo fato), ou trocar o número de referência do mesmo dado.
- **Vale (são fatos diferentes):** mesmo protagonista em acontecimentos diferentes ("Petrobras anuncia dividendos" e "Petrobras confirma nova descoberta"); o mesmo tema em países diferentes (inflação nos EUA e inflação na Alemanha).

**Exceção do fato dominante:** no máximo **1 fato por dia**, marcado no quadro como `dominante` com o motivo (ex.: guerra, decisão histórica, crash), pode aparecer em até 2 formatos, com ângulos diferentes. Nenhum outro fato repete.

**Histórico de 7 dias:** antes de escolher, montar a lista de fatos dos últimos 7 dias juntando duas fontes: `postados` (o que foi publicado) e `execucoes` do painel com status `concluida` ou `em_execucao` (o que foi produzido, mesmo sem publicar), mais os `mapa` de `pacotes/<data>` desses dias. A comparação com essa lista usa o **teste do mesmo fato** (as 3 perguntas acima: protagonista, ação e acontecimento), nunca só o `fato_id`, porque o `fato_id` leva a data e o mesmo assunto ganha outro id no dia seguinte. Fato que bate com algum item da lista fica `bloqueado-7-dias`, com a nota "já saiu em <data> (<formato>, <publicado ou produzido>)". Só volta se houver desdobramento novo (decisão, número ou fala diferente do que já saiu); nesse caso ganha `fato_id` novo e a nota "desdobramento de <fato_id antigo>: <o que mudou>". Na dúvida entre mesmo fato e desdobramento, tratar como mesmo fato. No quadro do dia, os bloqueados aparecem com essa nota, para o usuário ver o que ficou de fora e por quê.

**Conferência final:** antes de entregar, conferir o mapa. Achou fato repetido fora da exceção: trocar a peça do formato que reservou por último pela próxima candidata `livre` da mesma região e origem. A entrega sempre informa "0 fatos repetidos" ou o que foi trocado.

## 4. Stories (15 por dia)
**Divisão:** 12 do exterior (80%) e 3 do Brasil (20%).

**Distribuição dos 12 do exterior (no dia):**
- EUA: até 3
- Europa (UE, países europeus, Reino Unido, Suíça): pelo menos 3, incluindo um dos 22 países menores da UE quando houver fato relevante
- Ásia-Pacífico: pelo menos 2
- América Latina (fora o Brasil): pelo menos 1
- Oriente Médio e África: pelo menos 1
- O restante: Canadá, Rússia ou fatos globais (commodities, cripto, organismos internacionais)
- Nenhum país com mais de 3 stories no dia

**Três sequências de 5**, cada uma com 4 do exterior e 1 do Brasil:
| Sequência | Horário sugerido (Brasília) | O que entra |
|---|---|---|
| Manhã | ~8h | O que aconteceu na Ásia e na Europa durante a noite e a agenda do dia |
| Tarde | ~13h | Europa fechando, EUA abrindo e fatos políticos e geopolíticos do dia |
| Noite | ~19h | Fechamento de Wall Street, o fato do dia de cada região e o que esperar amanhã |

No fim de semana: manhã = a semana no mundo; tarde = geopolítica e personagens; noite = o que vem na próxima semana.

**Escolha por rodada (`stories manha|tarde|noite`):** escolher só a sequência pedida, com 4 do exterior e 1 do Brasil, olhando o que as sequências anteriores do dia já usaram no mapa. A manhã tenta cobrir Ásia e Europa; a tarde, Europa, EUA e América Latina; a noite fecha os mínimos de região que ainda faltarem no dia e respeita os limites (EUA até 3, nenhum país com mais de 3).

**Variedade:**
- Pelo menos 5 editorias diferentes nos 15 stories.
- Pelo menos 3 tipos de story por sequência: manchete, número do dia, citação curta e confirmada de personagem, país ou mapa, "por que importa para o Brasil", enquete.
- Política e geopolítica sempre com personagens citados (nome, cargo, partido ou país).
- Um fato por story. O primeiro story de cada sequência faz o papel de capa (manchete mais forte da sequência) e o último traz a ação (enquete, link ou chamada), como pede a stories-vantage.

**Falta de fato:** se não houver fato `livre` do Brasil, o slot do Brasil vira um story do exterior e isso é registrado. O Brasil nunca passa de 3 stories no dia (1 por sequência): se faltar fato numa região do exterior, completar com outra região do exterior ou com um story explicativo de um país ou indicador estrangeiro.

## 5. Reels (6 por dia: 3 longos e 3 curtos)
**Divisão:** 5 do exterior (cerca de 80%) e 1 do Brasil (cerca de 20%).
| Reel | Origem | O que entra |
|---|---|---|
| Longo 1 (30–50 s) | Exterior | O maior fato do mundo no dia, com personagem e consequência |
| Longo 2 (30–50 s) | Exterior | Análise de um fato de fora com efeito claro no Brasil (dólar, juros, commodities, exportações) |
| Longo 3 (30–50 s) | Exterior | Explicação de um tema de fora que está movendo mercados ou a geopolítica: contexto e o que vem a seguir |
| Curto 1 (20–35 s) | Exterior | Notícia urgente ou número forte de outra região |
| Curto 2 (20–35 s) | Exterior | Personagem ou fala do dia (confirmada) de outra região |
| Curto 3 (20–35 s) | Brasil | O fato brasileiro mais forte que ainda está `livre` |

**Critérios extras para Reel** (além da nota da pauta-vantage):
- Tem personagem, imagem forte ou movimento para mostrar.
- Cabe no tempo: o fato se explica em até duas frases no curto e em até quatro no longo.
- Tem um número ou uma fala que dá para dizer em voz alta.
- Fato que precisa de tabela, lista ou ranking vai para carrossel, não para Reel.

**Regiões:** os 5 Reels do exterior em pelo menos 3 regiões diferentes.

**Se o melhor fato do dia já está num carrossel:** ou ele é o fato dominante do dia (exceção da seção 3), ou o Reel pega a próxima candidata `livre`.

## 6. Entrega
1. **Quadro do dia completo:** todos os fatos, agrupados por região, uma linha por fato com nº, bandeira, resumo, editoria, nota e status (onde foi usado).
2. **Reels escolhidos (6):** nº do fato, formato, região, gancho, personagens e o motivo da escolha em uma linha.
3. **Stories escolhidos:** por sequência (manhã, tarde, noite), com nº do fato, país, tipo de story e gancho.
4. **Contagem:** Stories exterior / Brasil, Reels exterior / Brasil, regiões e editorias usadas no dia até aqui, e a conferência anti-repetição ("0 fatos repetidos" ou o que foi trocado).
5. **Reserva:** 3 fatos `livre` por formato, para troca rápida.
6. **Fontes** com links.

Salvar `selecao-reels.md` e `selecao-stories.md` na pasta do pacote e gravar no painel. No `/vantage-os`, cada Reel e cada sequência de Stories vira uma produção com `fato_id`, `origem`, `regiao` e `slot`.

## 7. Trocar uma escolha
`/selecao-vantage trocar <peça> <nº do fato>`:
- Fato `livre`: troca, atualiza o mapa, libera o fato antigo e confere de novo as cotas (80/20, regiões, editorias). Se a troca quebrar uma cota, avisar em uma linha, mas fazer a troca pedida.
- Fato já usado: dizer em qual peça ele está e oferecer as 3 reservas do formato.
- Se a produção da peça já começou no `/vantage-os`, a troca marca a produção antiga como `pulada` (nota "tema trocado pelo usuário") e cria uma nova `na_fila`. Nunca descartar narração já paga sem o usuário pedir a troca daquele Reel.

## 8. Cuidados
- Valem os cuidados editoriais da pauta-vantage (seção 10): sem recomendação de investimento, política equilibrada com personagens citados sem adjetivos, nada inventado, paráfrase com o veículo citado.
- Fato do exterior confirmado em agência ou veículo local, com o horário convertido para Brasília.
- Cargos de líderes estrangeiros confirmados na busca do dia.
- Guerras e conflitos: fatos e posições dos lados, sem imagens explícitas e sem tomar partido.