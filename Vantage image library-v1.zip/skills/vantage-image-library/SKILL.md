---
name: vantage-image-library
description: Skill de busca e seleção de imagens para o VANTAGE TIMES. Use quando uma matéria, carrossel ou post precisar de uma imagem representativa de pessoa, empresa, país, cidade, evento, mercado, indústria, objeto ou tema. Pesquisa múltiplas fontes, prioriza imagens reutilizáveis/licenciadas, escolhe o melhor asset e orienta o tratamento visual Vantage.
---

# VANTAGE IMAGE LIBRARY

## 1. OBJETIVO

Esta skill funciona como a camada de imagens do VANTAGE TIMES.

Fluxo obrigatório:

ASSUNTO DA MATÉRIA
→ identificar entidades e conceitos
→ buscar imagens em múltiplas fontes
→ filtrar qualidade/relevância/licença
→ selecionar a melhor imagem
→ aplicar ou solicitar tratamento visual Vantage
→ entregar asset pronto para o Designer.

A skill deve ser capaz de trabalhar com:
- pessoas
- empresas
- países
- cidades
- governos
- instituições
- mercados
- moedas
- commodities
- indústrias
- eventos
- guerras/conflitos
- eleições
- edifícios
- monumentos
- objetos
- tecnologia
- mapas
- bandeiras
- conceitos abstratos

---

# 2. FONTES

A arquitetura deve ser extensível.

Fontes prioritárias para imagens reutilizáveis/licenciadas:
1. Openverse
2. Wikimedia Commons
3. Unsplash
4. Pexels
5. Pixabay
6. Flickr
7. NASA / agências públicas
8. Europeana
9. outras APIs ou bancos autorizados adicionados posteriormente

Nunca presumir que uma imagem pode ser publicada apenas porque apareceu na busca.

Registrar:
- fonte
- URL da página original
- URL do arquivo quando disponível
- autor quando disponível
- licença
- requisitos de atribuição quando existirem

Se a licença não estiver clara, marcar:
**LICENÇA A VERIFICAR**

---

# 3. REGRA DE BUSCA

Para cada matéria, extrair:

### ENTIDADES
Exemplo:
“Petrobras anuncia novo plano de investimentos”

Entidades:
- Petrobras
- Brasil
- petróleo
- investimentos

### PESSOAS
Exemplo:
“Lula se reúne com Maduro”

Entidades:
- Lula
- Nicolás Maduro
- Brasília
- Venezuela
- Brasil

### CONTEXTO
Identificar:
- economia
- política
- geopolítica
- mercados
- indústria
- evento etc.

A pesquisa deve usar primeiro a entidade mais específica.

Exemplo:

PETROBRAS

é melhor que:

EMPRESA BRASILEIRA

---

# 4. BUSCA MULTIFONTE

Nunca depender de uma única fonte quando houver necessidade de qualidade.

Pesquisar em pelo menos duas fontes disponíveis.

Combinar:
- nome exato
- nome + contexto
- nome + local
- nome + evento

Exemplo:

“Petrobras”

“Petrobras Brazil”

“Petrobras oil platform”

Depois comparar resultados.

---

# 5. SELEÇÃO

Pontuar mentalmente cada imagem:

### RELEVÂNCIA — 40%
Representa diretamente a notícia?

### QUALIDADE — 20%
Resolução e nitidez suficientes?

### CONTEXTO — 15%
Ajuda a contar a história?

### COMPOSIÇÃO — 15%
Permite colocar texto e degradê?

### LICENÇA — 10%
A licença é clara e adequada?

Escolher a imagem com melhor equilíbrio, não simplesmente a primeira encontrada.

---

# 6. PESSOAS

Quando a matéria mencionar uma pessoa real:

Prioridade:
1. retrato/fotografia editorial da própria pessoa
2. fotografia contextual da pessoa no evento
3. fotografia oficial de fonte institucional
4. imagem contextual quando não houver foto adequada

Não usar uma pessoa diferente apenas porque a imagem é visualmente melhor.

Quando houver duas ou mais pessoas importantes:
- buscar cada pessoa
- considerar composição conjunta
- não misturar pessoas de épocas/eventos diferentes sem deixar isso claro

---

# 7. EMPRESAS

Exemplo:
PETROBRAS

Pesquisar preferencialmente:
- instalações
- plataformas
- sede
- operações
- executivos relacionados à notícia
- logo apenas quando a matéria for institucional ou corporativa

Não usar logo como substituto de uma fotografia contextual quando a matéria é sobre um acontecimento real.

---

# 8. PAÍSES

Para notícias sobre países, priorizar:

1. cena diretamente relacionada ao assunto
2. cidade/edifício/instituição relevante
3. paisagem ou infraestrutura
4. bandeira, apenas quando apropriado
5. mapa, principalmente em geopolítica

Não usar automaticamente a bandeira em toda notícia sobre o país.

---

# 9. GEOPOLÍTICA

Para:
- guerras
- conflitos
- diplomacia
- sanções
- alianças
- fronteiras
- relações internacionais

Priorizar:
- líderes envolvidos
- local do acontecimento
- mapa
- edifícios diplomáticos
- forças/instituições relacionadas
- imagens documentais

O fundo temático do Vantage pode ser:
**Editorial Lavender #D8D2E8**

---

# 10. MERCADOS

Para:
- bolsa
- dólar
- juros
- petróleo
- ouro
- criptomoedas
- índices

Priorizar:
- gráfico real
- pregão
- bolsa
- moeda
- commodity
- infraestrutura relacionada

Evitar imagens genéricas de “homem apertando botão de investimento” quando existir uma imagem mais editorial.

---

# 11. TRATAMENTO VANTAGE

A imagem selecionada não deve permanecer visualmente desconectada da identidade.

Tratamento recomendado:

FOTO ORIGINAL
→ contraste editorial
→ leve ajuste de saturação
→ máscara/gradiente
→ cor de identidade
→ área de leitura
→ texto
→ VT correto

### Fundos escuros
Preferir:
Deep Petrol #092F35
Ink Black #111111
Signal Lime #B7D900

### Fundos claros
Preferir:
Paper #F2F0E9
Ink Black #111111
Signal Lime #B7D900

### Geopolítica
Pode usar:
Editorial Lavender #D8D2E8

O gradiente deve ser elegante e controlado.

Nunca transformar a fotografia em um efeito neon exagerado.

---

# 12. GRADIENT_READY

Quando o sistema tiver capacidade de gerar uma versão tratada, criar:

`GRADIENT_READY`

A versão deve:
- preservar o assunto principal
- manter rosto/objeto reconhecível
- criar área negativa para texto
- usar a paleta Vantage
- manter aparência editorial
- não adicionar elementos que não existiam

Nome sugerido:

`petrobras_oil_platform_gradient_ready_01.jpg`

---

# 13. ORGANIZAÇÃO DE ASSETS

Estrutura recomendada:

11_SUBJECT_GRADIENTS/
├── PEOPLE/
├── COMPANIES/
├── COUNTRIES/
├── PLACES/
├── MARKETS/
├── INDUSTRIES/
├── GEOPOLITICS/
└── EVENTS/

Dentro de cada assunto:

PORTRAIT/
CONTEXT/
LOGO/
GRADIENT_READY/

Exemplo:

COMPANIES/
└── PETROBRAS/
    ├── PORTRAIT/
    ├── CONTEXT/
    ├── LOGO/
    └── GRADIENT_READY/

---

# 14. ESCALA GLOBAL

Não criar manualmente todas as pastas do mundo antecipadamente.

A estrutura deve ser dinâmica.

Se aparecer uma nova entidade:
- criar a categoria correspondente
- criar a pasta da entidade
- registrar metadados
- manter o padrão de nomenclatura

A biblioteca deve poder crescer para:
- 50+ países
- 100+ países
- 195 países
- milhares de pessoas
- milhares de empresas
- milhares de eventos

Sem mudar a arquitetura.

---

# 15. NOMENCLATURA

Usar nomes previsíveis:

`ENTIDADE_TEMA_TIPO_NUMERO`

Exemplos:

`petrobras_platform_context_01.jpg`

`lula_official_portrait_01.jpg`

`bolsonaro_portrait_01.jpg`

`brazil_brasilia_context_01.jpg`

`israel_iran_geopolitics_01.jpg`

`ibovespa_market_context_01.jpg`

Não usar:
`imagemfinal2.jpg`
`foto nova.jpg`
`IMG_9382.jpg`

---

# 16. METADADOS

Sempre que possível, registrar:

- subject
- category
- source
- source_url
- image_url
- author
- license
- attribution_required
- date_found
- orientation
- resolution
- usage_notes

Exemplo:

{
  "subject": "Petrobras",
  "category": "company",
  "source": "Wikimedia Commons",
  "license": "CC BY-SA",
  "attribution_required": true
}

---

# 17. ORIENTAÇÃO PARA O CARROSSEL

Se uma skill de carrossel fornecer um texto como:

“Petrobras anuncia…”

A skill de imagens deve devolver algo equivalente a:

SUBJECT:
Petrobras

PRIMARY IMAGE:
imagem contextual da Petrobras

ALTERNATIVE:
segunda imagem contextual

TREATMENT:
Deep Petrol gradient + Signal Lime

LICENSE:
informação da licença

SOURCE:
fonte original

O Designer então usa o asset.

---

# 18. QUANDO NÃO HOUVER IMAGEM BOA

Não escolher uma imagem ruim apenas para preencher o espaço.

Ordem de fallback:

1. buscar novamente com termos mais específicos
2. buscar contexto/evento relacionado
3. buscar mapa ou elemento visual documental
4. usar imagem institucional
5. usar composição gráfica/ilustração original
6. somente então usar imagem genérica

---

# 19. REGRAS DE SEGURANÇA E DIREITOS

A skill nunca deve afirmar:
“pode usar livremente”

sem verificar a licença.

Diferenciar:
- domínio público
- Creative Commons
- licença comercial
- atribuição obrigatória
- uso editorial
- licença desconhecida

Se a fonte não informar licença:
**LICENÇA A VERIFICAR**

Não remover créditos de uma obra quando a licença exigir atribuição.

---

# 20. REGRA DE PRIORIDADE

Quando houver conflito entre:

beleza visual × relevância

priorizar:
**RELEVÂNCIA**

Quando houver conflito entre:

relevância × licença inadequada

priorizar:
**LICENÇA ADEQUADA**

Quando houver duas imagens igualmente relevantes:
priorizar:
**melhor composição para o layout Vantage**

---

# 21. SAÍDA PADRÃO

Sempre que a skill encontrar uma imagem, retornar:

### IMAGEM PRINCIPAL
- assunto
- descrição
- fonte
- licença
- autor
- URL
- orientação recomendada

### ALTERNATIVA
- segunda opção

### TRATAMENTO
- fundo recomendado
- gradiente
- cor de destaque
- posição sugerida da imagem

### CARIMBO
- fundo claro → `VT_stamp_cream-background.png`
- fundo escuro → `VT_stamp_dark-background.png`

---

# 22. REGRA FINAL

O objetivo não é simplesmente “encontrar uma foto”.

O objetivo é:

**ENCONTRAR A IMAGEM CERTA → VALIDAR A LICENÇA → PREPARAR PARA O DESIGNER → MANTER A IDENTIDADE VANTAGE.**

A biblioteca deve funcionar como uma infraestrutura visual permanente do VANTAGE TIMES.
